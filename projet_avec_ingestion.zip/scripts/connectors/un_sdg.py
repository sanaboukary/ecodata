from typing import List, Dict, Any, Optional
import requests, os

UN_SDG_BASE_URL = os.getenv("UN_SDG_BASE_URL","https://unstats.un.org/SDGAPI/v1/sdg").rstrip("/")
HTTP_TIMEOUT = int(os.getenv("HTTP_TIMEOUT","30"))

def fetch_un_sdg(series: str, area: Optional[str] = None, time: Optional[str] = None, page_size: int = 10000) -> List[Dict[str, Any]]:
    params = {"seriesCode": series, "pageSize": page_size}
    if area: params["areaCode"] = area
    if time: params["timePeriod"] = time
    url = f"{UN_SDG_BASE_URL}/Series/Data"
    r = requests.get(url, params=params, timeout=HTTP_TIMEOUT)
    r.raise_for_status()
    data = r.json()
    rows = data.get("data", [])
    out=[]
    for row in rows:
        try:
            time_period = str(row.get("timePeriod"))
            val = row.get("value"); geo = row.get("geoAreaCode") or row.get("geoAreaName")
            if val is None or time_period is None: continue
            ts = f"{time_period}-01-01T00:00:00Z" if len(time_period)==4 else f"{time_period}T00:00:00Z"
            out.append({"source":"UN_SDG","dataset":series,"key":f"{geo}.{series}","ts":ts,"value":float(val),"attrs":{"geo":geo}})
        except Exception:
            continue
    return out
