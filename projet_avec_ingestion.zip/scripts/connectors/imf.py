from typing import List, Dict, Any
import requests, os

IMF_BASE_URL = os.getenv("IMF_BASE_URL","https://dataservices.imf.org/REST/SDMX_JSON.svc").rstrip("/")
HTTP_TIMEOUT = int(os.getenv("HTTP_TIMEOUT","30"))

def fetch_imf_compact(dataset: str, key: str) -> List[Dict[str, Any]]:
    url = f"{IMF_BASE_URL}/CompactData/{dataset}/{key}"
    r = requests.get(url, timeout=HTTP_TIMEOUT)
    r.raise_for_status()
    data = r.json()
    series = data.get("CompactData", {}).get("DataSet", {}).get("Series")
    if not series: return []
    if isinstance(series, dict): series = [series]
    out=[]
    for s in series:
        obs = s.get("Obs") or []
        if isinstance(obs, dict): obs=[obs]
        key_full = ".".join([str(v) for v in s.values() if isinstance(v,str)])
        for o in obs:
            t = o.get("@TIME_PERIOD"); v = o.get("@OBS_VALUE")
            if not (t and v): continue
            ts = f"{t}-01-01T00:00:00Z" if len(t)==4 else f"{t}T00:00:00Z"
            out.append({"source":"IMF","dataset":dataset,"key":key_full or key,"ts":ts,"value":float(v),"attrs":{}})
    return out
