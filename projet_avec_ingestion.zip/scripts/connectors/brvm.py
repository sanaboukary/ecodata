from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
import random, os, requests
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

BRVM_API_URL = os.getenv("BRVM_API_URL","").strip()
HTTP_TIMEOUT = int(os.getenv("HTTP_TIMEOUT","30"))

class BRVMClientError(Exception): pass

@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10), reraise=True,
       retry=retry_if_exception_type((requests.RequestException, BRVMClientError)))
def fetch_brvm(api_url: Optional[str] = None) -> List[Dict[str, Any]]:
    url = (api_url or BRVM_API_URL).strip()
    now = datetime.now(timezone.utc).replace(second=0, microsecond=0)
    if not url:
        # Simulation if no official API configured
        symbols = ["BRVM-AAA","BRVM-BBB","BRVM-CCC"]
        out=[]
        for s in symbols:
            o = round(random.uniform(80,120),2)
            h = round(o*random.uniform(1.00,1.03),2)
            l = round(o*random.uniform(0.97,1.00),2)
            c = round(random.uniform(l,h),2)
            v = random.randint(1_000,50_000)
            out.append({"symbol":s,"ts":now.isoformat(),"open":o,"high":h,"low":l,"close":c,"volume":v,"source":"BRVM"})
        return out
    r = requests.get(url, timeout=HTTP_TIMEOUT)
    if r.status_code != 200:
        raise BRVMClientError(f"HTTP {r.status_code}")
    data = r.json()
    records = data.get("records") or data
    out=[]
    for rec in records:
        try:
            out.append({
                "symbol": rec["symbol"],
                "ts": rec.get("datetime") or rec.get("ts") or now.isoformat(),
                "open": float(rec["open"]), "high": float(rec["high"]),
                "low": float(rec["low"]), "close": float(rec["close"]),
                "volume": int(rec.get("volume") or 0), "source": "BRVM"
            })
        except Exception:
            continue
    return out
