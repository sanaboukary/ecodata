from pymongo import MongoClient, ASCENDING
from datetime import datetime

def get_db(uri, name):
    client = MongoClient(uri)
    return client[name]

def write_raw(db, source, payload):
    col = db.raw_events
    col.create_index([("source", ASCENDING), ("fetched_at", ASCENDING)])
    col.insert_one({"source": source, "fetched_at": datetime.utcnow(), "payload": payload})

def upsert_observations(db, obs):
    col = db.curated_observations
    col.create_index([("source", ASCENDING), ("dataset", ASCENDING), ("key", ASCENDING), ("ts", ASCENDING)], unique=True)
    for r in obs:
        q = {"source": r["source"], "dataset": r["dataset"], "key": r["key"], "ts": r["ts"]}
        col.update_one(q, {"$set": r}, upsert=True)
