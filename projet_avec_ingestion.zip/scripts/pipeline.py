from typing import List, Dict
from .settings import MONGO_URI, MONGO_DB
from .mongo_utils import get_db, write_raw, upsert_observations
from .connectors.brvm import fetch_brvm
from .connectors.worldbank import fetch_worldbank_indicator
from .connectors.imf import fetch_imf_compact
from .connectors.un_sdg import fetch_un_sdg
from .connectors.afdb import fetch_afdb_sdmx

def normalize_brvm(records: List[Dict]) -> List[Dict]:
    out = []
    for r in records:
        out.append({
            "source": "BRVM", "dataset": "QUOTES", "key": r["symbol"],
            "ts": r["ts"], "value": r["close"],
            "attrs": {"open": r["open"], "high": r["high"], "low": r["low"], "volume": r["volume"]}
        })
    return out

def run_ingestion(source: str, **kwargs) -> int:
    db = get_db(MONGO_URI, MONGO_DB)
    if source == "brvm":
        recs = fetch_brvm()
        write_raw(db, "BRVM", recs)
        obs = normalize_brvm(recs)
        upsert_observations(db, obs)
        return len(obs)
    if source == "worldbank":
        obs = fetch_worldbank_indicator(kwargs.get("indicator"), kwargs.get("date"), kwargs.get("country","all"))
        write_raw(db, "WorldBank", {"params": kwargs, "rows": len(obs)})
        upsert_observations(db, obs); return len(obs)
    if source == "imf":
        obs = fetch_imf_compact(kwargs.get("dataset"), kwargs.get("key"))
        write_raw(db, "IMF", {"params": kwargs, "rows": len(obs)})
        upsert_observations(db, obs); return len(obs)
    if source == "un":
        obs = fetch_un_sdg(kwargs.get("series"), kwargs.get("area"), kwargs.get("time"))
        write_raw(db, "UN_SDG", {"params": kwargs, "rows": len(obs)})
        upsert_observations(db, obs); return len(obs)
    if source == "afdb":
        obs = fetch_afdb_sdmx(kwargs.get("dataset"), kwargs.get("key"))
        write_raw(db, "AfDB", {"params": kwargs, "rows": len(obs)})
        upsert_observations(db, obs); return len(obs)
    raise ValueError("Unknown source")
