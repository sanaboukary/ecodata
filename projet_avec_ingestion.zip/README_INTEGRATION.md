# Intégration ETL automatique (BRVM horaire + FMI/BM/ONU/BAD) pour votre projet Django

Cette intégration ajoute:
- `scripts/` : connecteurs (BRVM, World Bank, IMF, UN SDG, AfDB), pipeline unifié et scheduler (APScheduler).
- `ingestion/` : application Django (API health + démarrage d’ingestion) et **deux commandes**:
  - `python manage.py ingest_source --source brvm|worldbank|imf|un|afdb [options]`
  - `python manage.py start_scheduler` (BRVM toutes les heures)

## Installation
1) Copier le contenu de ce ZIP à la racine de votre projet (à côté de `manage.py`).
2) Ajouter `ingestion` à `INSTALLED_APPS` dans `settings.py`.
3) Ajouter les URLs:
```py
# urls.py
from django.urls import path, include
urlpatterns = [
    # ...
    path("api/ingestion/", include("ingestion.urls")),
]
```
4) Installer dépendances:
```bash
pip install -r requirements.txt
# puis ajoutez ces paquets :
pip install -r requirements_etl.txt
```

## Config (.env)
On lit `MONGODB_URI` et `MONGODB_NAME` (déjà présents dans votre `.env`).

## Utilisation
- **Ingestion ponctuelle**:
```bash
python manage.py ingest_source --source brvm
python manage.py ingest_source --source worldbank --indicator SP.POP.TOTL --date 2010:2024 --country CIV
python manage.py ingest_source --source imf --dataset IFS --key M.US.PCPI_IX
python manage.py ingest_source --source un --series SL_TLF_UEM
python manage.py ingest_source --source afdb --dataset YOUR_DATASET --key YOUR_KEY
```

- **Planification horaire (BRVM)**:
```bash
python manage.py start_scheduler
```

MongoDB:
- `raw_events` : documents bruts
- `curated_observations` : format unifié `{source,dataset,key,ts,value,attrs}`

