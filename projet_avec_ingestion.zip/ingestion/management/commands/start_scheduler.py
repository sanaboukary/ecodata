from django.core.management.base import BaseCommand
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime
from scripts.pipeline import run_ingestion

def brvm_job():
    print(f"[{datetime.utcnow().isoformat()}Z] BRVM hourly ingestion (Django scheduler)...")
    n = run_ingestion("brvm")
    print(f"Ingested {n} BRVM observations.")

class Command(BaseCommand):
    help = "Start the BRVM hourly scheduler (APScheduler)"

    def handle(self, *args, **opts):
        sched = BlockingScheduler(timezone="UTC")
        sched.add_job(brvm_job, CronTrigger.from_crontab("0 * * * *"))
        self.stdout.write(self.style.SUCCESS("Scheduler started (hourly BRVM). Ctrl+C to stop."))
        sched.start()
